#include "ui.h"

#include <lvgl.h>
#include <cmath>
#include <cstdio>

#include "config.h"

namespace {

lv_obj_t *s_arc = nullptr;
lv_obj_t *s_percent_label = nullptr;
lv_obj_t *s_pulse_label = nullptr;
lv_obj_t *s_toast_label = nullptr;
lv_timer_t *s_toast_timer = nullptr;

UiPercentChangedCb s_user_cb = nullptr;

void hide_toast_timer_cb(lv_timer_t *timer) {
    lv_obj_add_flag(s_toast_label, LV_OBJ_FLAG_HIDDEN);
    s_toast_timer = nullptr;
}

void arc_event_cb(lv_event_t *e) {
    lv_obj_t *arc = static_cast<lv_obj_t *>(lv_event_get_target(e));
    const int16_t value = lv_arc_get_value(arc);
    if (s_user_cb) {
        s_user_cb(static_cast<float>(value));
    }
}

// LVGL 8.4's lv_arc has a bug in its own touch-drag handling for arcs whose
// background sweep doesn't start at angle 0 (ours starts at 180): the angle
// it computes for the touch point gets compared against the wrong frame of
// reference, so touches on the visible (top) half are rejected as "outside"
// (no-op) while touches on the empty (bottom) half are wrongly accepted and
// clamped to the max value. We bypass lv_arc's own dragging logic entirely
// (the arc is left non-clickable) and compute the angle ourselves here,
// listening on the screen so drags starting anywhere still work.
constexpr int kArcTouchInnerRadius = 60;  // ignore taps over the center labels
constexpr int kArcTouchOuterRadius = 130; // ignore stray taps near the bezel

void arc_touch_cb(lv_event_t *e) {
    lv_indev_t *indev = lv_indev_get_act();
    if (!indev) {
        return;
    }

    lv_point_t p;
    lv_indev_get_point(indev, &p);

    const int dx = p.x - DISPLAY_WIDTH / 2;
    const int dy = p.y - DISPLAY_HEIGHT / 2;
    const int dist_sq = dx * dx + dy * dy;
    if (dist_sq < kArcTouchInnerRadius * kArcTouchInnerRadius ||
        dist_sq > kArcTouchOuterRadius * kArcTouchOuterRadius) {
        return;
    }
    if (dy > 0) {
        return; // bottom half - outside the arc's 180-360 deg sweep
    }

    // Screen-space angle, 0 deg = 3 o'clock, increasing clockwise (matches
    // lv_arc_set_bg_angles(180, 360): 9 o'clock -> 12 o'clock -> 3 o'clock).
    constexpr float kRadToDeg = 57.29577951308232f;
    float angle_deg = std::atan2(static_cast<float>(dy), static_cast<float>(dx)) * kRadToDeg;
    if (angle_deg < 180.0f) {
        angle_deg += 360.0f; // wrap the dy==0, dx>0 case (0 deg) up to 360
    }

    const float span = OUTPUT_PERCENT_MAX - OUTPUT_PERCENT_MIN;
    const float percent = OUTPUT_PERCENT_MIN + (angle_deg - 180.0f) / 180.0f * span;
    const int16_t value = static_cast<int16_t>(std::lround(percent));

    if (value != lv_arc_get_value(s_arc)) {
        lv_arc_set_value(s_arc, value);
        lv_event_send(s_arc, LV_EVENT_VALUE_CHANGED, nullptr);
    }
}

} // namespace

void ui_init(UiPercentChangedCb on_user_percent_changed) {
    s_user_cb = on_user_percent_changed;

    lv_obj_t *scr = lv_scr_act();
    lv_obj_set_style_bg_color(scr, lv_color_black(), 0);

    // --- 180-degree draggable arc gauge (9 o'clock -> 12 o'clock -> 3 o'clock) ---
    s_arc = lv_arc_create(scr);
    lv_obj_set_size(s_arc, 222, 222);
    lv_obj_center(s_arc);
    lv_arc_set_bg_angles(s_arc, 180, 360);
    lv_arc_set_range(s_arc, static_cast<int16_t>(OUTPUT_PERCENT_MIN),
                      static_cast<int16_t>(OUTPUT_PERCENT_MAX));
    lv_arc_set_value(s_arc, static_cast<int16_t>(OUTPUT_PERCENT_DEFAULT));

    // lv_arc's built-in touch dragging is buggy for a 180-360 deg sweep (see
    // arc_touch_cb above), so leave the arc non-clickable and drive it from
    // our own screen-level touch handler instead.
    lv_obj_clear_flag(s_arc, LV_OBJ_FLAG_CLICKABLE);

    lv_obj_set_style_arc_width(s_arc, 18, LV_PART_MAIN);
    lv_obj_set_style_arc_color(s_arc, lv_color_hex(0x303030), LV_PART_MAIN);
    lv_obj_set_style_arc_width(s_arc, 18, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(s_arc, lv_color_hex(0x00c2a8), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(s_arc, lv_color_hex(0x00c2a8), LV_PART_KNOB);
    lv_obj_set_style_pad_all(s_arc, 6, LV_PART_KNOB);

    lv_obj_add_event_cb(s_arc, arc_event_cb, LV_EVENT_VALUE_CHANGED, nullptr);
    lv_obj_add_event_cb(scr, arc_touch_cb, LV_EVENT_PRESSED, nullptr);
    lv_obj_add_event_cb(scr, arc_touch_cb, LV_EVENT_PRESSING, nullptr);

    // --- 50% reference tick (straight up = midpoint of the 180-360 sweep) ---
    lv_obj_t *tick = lv_obj_create(scr);
    lv_obj_remove_style_all(tick);
    lv_obj_set_size(tick, 4, 14);
    lv_obj_set_style_bg_color(tick, lv_color_hex(0x808080), 0);
    lv_obj_set_style_bg_opa(tick, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(tick, 2, 0);
    lv_obj_align(tick, LV_ALIGN_TOP_MID, 0, 6);

    // --- Big center %, caption, and pulse-width readout ---
    s_percent_label = lv_label_create(scr);
    lv_obj_set_style_text_font(s_percent_label, &lv_font_montserrat_48, 0);
    lv_obj_set_style_text_color(s_percent_label, lv_color_white(), 0);
    lv_label_set_text(s_percent_label, "50%");
    lv_obj_align(s_percent_label, LV_ALIGN_CENTER, 0, -14);

    lv_obj_t *caption = lv_label_create(scr);
    lv_obj_set_style_text_font(caption, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(caption, lv_color_hex(0x808080), 0);
    lv_label_set_text(caption, "SERVO OUTPUT");
    lv_obj_align_to(caption, s_percent_label, LV_ALIGN_OUT_BOTTOM_MID, 0, 4);

    s_pulse_label = lv_label_create(scr);
    lv_obj_set_style_text_font(s_pulse_label, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(s_pulse_label, lv_color_hex(0x606060), 0);
    lv_label_set_text(s_pulse_label, "1500 us");
    lv_obj_align_to(s_pulse_label, caption, LV_ALIGN_OUT_BOTTOM_MID, 0, 2);

    // --- Reset toast (hidden until the ring button is pressed) ---
    s_toast_label = lv_label_create(scr);
    lv_obj_set_style_text_font(s_toast_label, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(s_toast_label, lv_color_hex(0x00c2a8), 0);
    lv_label_set_text(s_toast_label, "RESET TO 50%");
    lv_obj_align(s_toast_label, LV_ALIGN_BOTTOM_MID, 0, -20);
    lv_obj_add_flag(s_toast_label, LV_OBJ_FLAG_HIDDEN);
}

void ui_set_percent(float percent) {
    lv_arc_set_value(s_arc, static_cast<int16_t>(std::lround(percent)));
    lv_label_set_text_fmt(s_percent_label, "%d%%", static_cast<int>(std::lround(percent)));
}

void ui_set_pulse_us(int pulse_us) {
    lv_label_set_text_fmt(s_pulse_label, "%d us", pulse_us);
}

void ui_show_reset_toast() {
    lv_obj_clear_flag(s_toast_label, LV_OBJ_FLAG_HIDDEN);
    if (s_toast_timer) {
        lv_timer_reset(s_toast_timer);
    } else {
        s_toast_timer = lv_timer_create(hide_toast_timer_cb, 900, nullptr);
        lv_timer_set_repeat_count(s_toast_timer, 1);
    }
}
