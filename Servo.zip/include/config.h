#pragma once

#include <cstdint>

// ---------------------------------------------------------------------------
// Servo PWM output (Port B)
// ---------------------------------------------------------------------------
// M5Dial Port B exposes GND, 5V, G1 (GPIO1) and G1 (GPIO1, closest to 5V).
// The servo signal wire is connected to G1; power the servo from Port B's
// 5V/GND pins (fine for a single micro/standard servo; use a separate supply
// if the servo stalls or draws more current than the M5Dial's regulator
// can provide).
constexpr int SERVO_PWM_PIN = 1; // GPIO1 / Port B "G1"

constexpr int SERVO_PWM_FREQ_HZ = 50;     // Standard analog servo frequency
constexpr int SERVO_PWM_RESOLUTION_BITS = 12; // 4096 steps @ 50Hz -> ~4.9us/step
constexpr int SERVO_PULSE_MIN_US = 1000;  // Pulse width at 0%
constexpr int SERVO_PULSE_MAX_US = 2000;  // Pulse width at 100%

// ---------------------------------------------------------------------------
// Rotary encoder / outer ring
// ---------------------------------------------------------------------------
// If turning the ring clockwise makes the value go DOWN instead of up on your
// unit, flip this to true.
constexpr bool ENCODER_INVERT_DIRECTION = false;

// The M5Dial's encoder is a standard quadrature encoder with 16 detents per
// revolution at 4 quadrature counts per detent (64 counts/rev). One "detent"
// of rotation is therefore 4 raw counts from M5Dial.Encoder.read().
constexpr int ENCODER_COUNTS_PER_DETENT = 4;

// Acceleration curve: the % step applied per detent depends on how quickly
// the user is turning the dial (time between detents, in milliseconds).
// Tune these to taste.
struct EncoderAccelStep {
    uint32_t max_interval_ms; // if time-between-detents <= this, use this step
    float step_percent;
};
constexpr EncoderAccelStep ENCODER_ACCEL_TABLE[] = {
    {20, 40.0f},  // very fast flick (~3+ rev/sec)
    {50, 20.0f},  // fast spin (~2 rev/sec)
    {100, 10.0f}, // brisk turn (~1 rev/sec)
    {220, 5.0f},  // moderate turn (~0.5 rev/sec)
    {UINT32_MAX, 3.0f}, // slow, deliberate turn (fallback)
};

// ---------------------------------------------------------------------------
// Output percentage
// ---------------------------------------------------------------------------
constexpr float OUTPUT_PERCENT_MIN = 0.0f;
constexpr float OUTPUT_PERCENT_MAX = 100.0f;
constexpr float OUTPUT_PERCENT_DEFAULT = 50.0f; // startup value & ring-button reset target

// ---------------------------------------------------------------------------
// Display / UI
// ---------------------------------------------------------------------------
constexpr int DISPLAY_WIDTH = 240;
constexpr int DISPLAY_HEIGHT = 240;

// LVGL draw buffer: number of pixel rows buffered at a time (partial render).
constexpr int LVGL_DRAW_BUF_LINES = 40;
