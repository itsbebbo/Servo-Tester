#pragma once

// Called whenever the user drags the on-screen arc to a new value.
// percent is in the arc's native 0-100 range.
using UiPercentChangedCb = void (*)(float percent);

// Builds the screen: a 180-degree draggable arc gauge, a big % readout,
// and a pulse-width (microseconds) readout. on_user_percent_changed is
// invoked when the user drags the arc directly on the touchscreen.
void ui_init(UiPercentChangedCb on_user_percent_changed);

// Reflects an externally-driven value (from the rotary ring or a reset)
// onto the arc and labels. Does not re-trigger on_user_percent_changed.
void ui_set_percent(float percent);

// Updates the microsecond pulse-width readout.
void ui_set_pulse_us(int pulse_us);

// Briefly shows a "RESET TO 50%" toast, e.g. after the ring button is pressed.
void ui_show_reset_toast();
