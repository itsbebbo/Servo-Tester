#include <M5Dial.h>
#include <algorithm>

#include "config.h"
#include "display_driver.h"
#include "encoder_input.h"
#include "servo.h"
#include "ui.h"

namespace {

float g_target_percent = OUTPUT_PERCENT_DEFAULT;
EncoderInput g_encoder;

void apply_percent(float percent) {
    percent = std::clamp(percent, OUTPUT_PERCENT_MIN, OUTPUT_PERCENT_MAX);
    g_target_percent = percent;

    servo_set_percent(percent);
    ui_set_percent(percent);
    ui_set_pulse_us(servo_last_pulse_us());
}

// Fired when the user drags the on-screen arc directly.
void on_arc_dragged(float percent) {
    apply_percent(percent);
}

} // namespace

void setup() {
    Serial.begin(115200);

    auto cfg = M5.config();
    M5Dial.begin(cfg, /*enableEncoder=*/true, /*enableRFID=*/false);

    display_driver_init();
    ui_init(on_arc_dragged);
    servo_init();
    g_encoder.begin();

    apply_percent(OUTPUT_PERCENT_DEFAULT);
}

void loop() {
    M5Dial.update();
    display_driver_task_handler();

    const float delta_percent = g_encoder.poll();
    if (delta_percent != 0.0f) {
        apply_percent(g_target_percent + delta_percent);
    }

    if (M5Dial.BtnA.wasPressed()) {
        apply_percent(OUTPUT_PERCENT_DEFAULT);
        ui_show_reset_toast();
        M5Dial.Speaker.tone(8000, 30);
    }

    delay(5);
}
